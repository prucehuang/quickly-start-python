# !usr/bin/env python
# coding:utf-8

"""

author: ${USER} 
 email: 1756983926@qq.com
  date: ${YEAR}/${MONTH}/${DAY}
"""

if __name__ == "__main__":
    print('Hello, Welcome to My World')